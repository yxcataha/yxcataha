<?php
	$host = "localhost";
	$user = "root";
	$passw = "";
	
	$bot_token = "";
	$ch_id = '';
	
	$card = '';
	
	$xmr = "";
	$vwk = "";
	
	$btc = "";
	$eth = "";
	$dash = "";
	$ltc = "";
?>